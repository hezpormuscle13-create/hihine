package com.deskpet.app

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Dự phòng: bắt phím cứng khi không có Shizuku (không bắt được chuột). */
class KeyAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val pet = PetBus.pet
        if (pet != null && !PetBus.shizukuActive && event.repeatCount == 0) {
            val down = event.action == KeyEvent.ACTION_DOWN
            val id = event.keyCode.toString().hashCode()
            pet.post { pet.onKey(id, down) }
        }
        return false
    }
}
