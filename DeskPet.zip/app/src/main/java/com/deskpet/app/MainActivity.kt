package com.deskpet.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private val prefs by lazy { getSharedPreferences("pet", MODE_PRIVATE) }

    private val shizukuListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "🐰 Thỏ trên màn hình"
            textSize = 22f
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, pad, 0, pad) }
        root.addView(status)

        fun btn(label: String, onClick: () -> Unit): Button {
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { onClick() }
            }
            root.addView(b)
            return b
        }

        btn("1. Cấp quyền lớp phủ (hiển thị trên ứng dụng khác)") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("2. Cấp quyền Shizuku (đọc chuột + phím thật)") { requestShizuku() }
        btn("3. Cho phép thông báo") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
        btn("4. Bỏ tối ưu pin (chạy nền ổn định)") {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        btn("5. (Tuỳ chọn) Trợ năng – bắt phím khi không có Shizuku") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        toggle = btn("") { togglePet() }

        root.addView(TextView(this).apply { text = "Kích thước thỏ"; setPadding(0, pad, 0, 0) })
        root.addView(SeekBar(this).apply {
            max = 150
            progress = prefs.getInt("size", 100) - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    prefs.edit().putInt("size", p + 50).apply()
                    if (PetBus.pet != null) {
                        startService(Intent(this@MainActivity, PetService::class.java)
                            .setAction(PetService.ACTION_RESIZE))
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        root.addView(Switch(this).apply {
            text = "Tự chạy khi mở máy"
            isChecked = prefs.getBoolean("autostart", false)
            setPadding(0, pad, 0, 0)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("autostart", c).apply() }
        })

        root.addView(TextView(this).apply {
            text = "\nCách dùng: cắm chuột/bàn phím OTG, bật Shizuku, cấp đủ quyền rồi bấm BẬT. " +
                "Kéo thỏ để di chuyển. Thoát app thỏ vẫn chạy; tắt bằng nút trong app hoặc thông báo."
            textSize = 13f
        })

        setContentView(ScrollView(this).apply { addView(root) })
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun shizukuState(): Int = try {
        if (!Shizuku.pingBinder()) 0
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
    } catch (_: Throwable) { 0 }

    private fun requestShizuku() {
        when (shizukuState()) {
            0 -> {
                Toast.makeText(this, "Hãy mở app Shizuku và bật dịch vụ trước", Toast.LENGTH_LONG).show()
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    ?.let { startActivity(it) }
            }
            1 -> try { Shizuku.requestPermission(100) } catch (_: Throwable) {}
            else -> Toast.makeText(this, "Đã cấp quyền Shizuku rồi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePet() {
        if (PetBus.pet != null) {
            startService(Intent(this, PetService::class.java).setAction(PetService.ACTION_STOP))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Cần cấp quyền lớp phủ trước", Toast.LENGTH_LONG).show()
                return
            }
            ContextCompat.startForegroundService(this, Intent(this, PetService::class.java))
        }
        toggle.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val sz = when (shizukuState()) {
            2 -> "✅ đã chạy + đã cấp quyền"
            1 -> "⚠️ đang chạy, chưa cấp quyền cho app"
            else -> "❌ chưa chạy"
        }
        val notif = if (Build.VERSION.SDK_INT >= 33)
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else true
        val battery = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        status.text = "Lớp phủ: ${if (overlay) "✅" else "❌"}\n" +
            "Shizuku: $sz\n" +
            "Thông báo: ${if (notif) "✅" else "❌"}\n" +
            "Bỏ tối ưu pin: ${if (battery) "✅" else "❌"}"
        toggle.text = if (PetBus.pet != null) "⏹ TẮT thỏ" else "▶ BẬT thỏ"
    }
}
