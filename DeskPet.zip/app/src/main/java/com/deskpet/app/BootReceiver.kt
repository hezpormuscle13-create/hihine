package com.deskpet.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("pet", Context.MODE_PRIVATE)
        if (prefs.getBoolean("autostart", false) && Settings.canDrawOverlays(context)) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, PetService::class.java))
            } catch (_: Throwable) {
            }
        }
    }
}
