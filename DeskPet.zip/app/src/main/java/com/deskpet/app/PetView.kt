package com.deskpet.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

/** Nhân vật thỏ ngồi bàn: tay phải cầm chuột, tay trái bấm phím. Toàn bộ vẽ bằng Canvas. */
class PetView(ctx: Context, var scaleFactor: Float) : View(ctx) {

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val dens = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = INK
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rect = RectF()
    private val path = Path()

    // tay chuột (lệch so với vị trí nghỉ)
    private var mTx = 0f
    private var mTy = 0f
    private var mX = 0f
    private var mY = 0f

    // tay phím
    private var kx = 110f
    private var ky = 188f
    private var kTx = 110f
    private var kTy = 188f
    private var heldKey = -1
    private var keyCol = 0
    private var keyRow = 0
    private var keyDown = false
    private var keyPressUntil = 0L

    private var mouseDown = false
    private var clickUntil = 0L
    private var activeUntil = 0L

    companion object {
        private const val INK = 0xFF4A2E1F.toInt()
        private const val CREAM = 0xFFFCE3C0.toInt()
        private const val W = 300f
        private const val H = 230f
        private const val KX0 = 88f
        private const val KY0 = 165f
        private const val KCW = 12.2f
        private const val KCH = 10f
    }

    // ---------- nhận tín hiệu ----------
    fun onMouseMove(dx: Int, dy: Int) {
        mTx = (mTx + dx * 0.7f).coerceIn(-14f, 14f)
        mTy = (mTy + dy * 0.7f).coerceIn(-9f, 9f)
        wake()
    }

    fun onWheel(v: Int) {
        mTy = (mTy - v * 3f).coerceIn(-9f, 9f)
        wake()
    }

    fun onClick(down: Boolean) {
        mouseDown = down
        if (down) clickUntil = SystemClock.uptimeMillis() + 110
        wake()
    }

    fun onKey(id: Int, down: Boolean) {
        if (down) {
            val h = (id * 31 + 7) and 0x7fffffff
            keyCol = h % 10
            keyRow = (h / 10) % 3
            heldKey = id
            keyDown = true
            keyPressUntil = SystemClock.uptimeMillis() + 110
            kTx = KX0 + keyCol * KCW + KCW / 2
            kTy = KY0 + keyRow * KCH + 14f
        } else if (id == heldKey) {
            keyDown = false
        }
        wake()
    }

    private fun wake() {
        activeUntil = SystemClock.uptimeMillis() + 1500
        postInvalidateOnAnimation()
    }

    // ---------- kích thước + kéo thả ----------
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (W * 0.8f * dens * scaleFactor).toInt()
        val h = (H * 0.8f * dens * scaleFactor).toInt()
        setMeasuredDimension(w, h)
    }

    private var lastX = 0f
    private var lastY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    lastX = e.rawX; lastY = e.rawY
                    onDrag?.invoke(dx, dy)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { onDragEnd?.invoke(); return true }
        }
        return super.onTouchEvent(e)
    }

    // ---------- vẽ ----------
    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        mTx *= 0.95f; mTy *= 0.95f
        mX += (mTx - mX) * 0.4f; mY += (mTy - mY) * 0.4f
        kx += (kTx - kx) * 0.35f; ky += (kTy - ky) * 0.35f
        val keyPressed = keyDown || now < keyPressUntil
        val clicking = mouseDown || now < clickUntil

        canvas.save()
        val s = width / W
        canvas.scale(s, s)

        drawDesk(canvas)
        drawHead(canvas)
        drawKeyboard(canvas, keyPressed)
        drawMouseAndArms(canvas, keyPressed, clicking)
        canvas.restore()

        if (now < activeUntil) postInvalidateOnAnimation()
    }

    private fun drawDesk(c: Canvas) {
        rect.set(8f, 168f, 292f, 228f)
        fill.color = 0xFFE8B87A.toInt()
        c.drawOval(rect, fill)
        line.strokeWidth = 3.5f
        c.drawOval(rect, line)
    }

    private fun drawHead(c: Canvas) {
        // tai
        for (side in intArrayOf(-1, 1)) {
            val cx = 150f + 30f * side
            c.save()
            c.rotate(8f * side, cx, 40f)
            rect.set(cx - 13f, 8f, cx + 13f, 72f)
            fill.color = CREAM
            c.drawOval(rect, fill)
            line.strokeWidth = 3.5f
            c.drawOval(rect, line)
            rect.set(cx - 7f, 16f, cx + 7f, 62f)
            fill.color = 0xFFFFB8C8.toInt()
            c.drawOval(rect, fill)
            c.restore()
        }
        // đầu
        fill.color = CREAM
        c.drawCircle(150f, 108f, 60f, fill)
        line.strokeWidth = 4f
        c.drawCircle(150f, 108f, 60f, line)

        // mắt nhìn theo chuột
        val ex = mX / 14f * 2.5f
        val ey = mY / 9f * 2f
        fill.color = INK
        c.drawCircle(128f + ex, 110f + ey, 5f, fill)
        c.drawCircle(172f + ex, 110f + ey, 5f, fill)
        fill.color = 0xFFFFFFFF.toInt()
        c.drawCircle(129.5f + ex, 108.5f + ey, 1.6f, fill)
        c.drawCircle(173.5f + ex, 108.5f + ey, 1.6f, fill)

        // má hồng
        fill.color = 0x99FF8FA3.toInt()
        rect.set(100f, 120f, 120f, 132f); c.drawOval(rect, fill)
        rect.set(180f, 120f, 200f, 132f); c.drawOval(rect, fill)

        // miệng
        line.strokeWidth = 2.5f
        path.reset()
        path.moveTo(143f, 121f)
        path.quadTo(146.5f, 127f, 150f, 121f)
        path.quadTo(153.5f, 127f, 157f, 121f)
        c.drawPath(path, line)
    }

    private fun drawKeyboard(c: Canvas, pressed: Boolean) {
        rect.set(82f, 160f, 218f, 200f)
        fill.color = 0xFFD9D9E0.toInt()
        c.drawRoundRect(rect, 6f, 6f, fill)
        line.strokeWidth = 2.5f
        c.drawRoundRect(rect, 6f, 6f, line)
        for (r in 0..2) for (col in 0..9) {
            val hit = pressed && r == keyRow && col == keyCol
            fill.color = when {
                hit -> 0xFFFF7F9C.toInt()
                r == 0 && col < 2 -> 0xFFF5B35C.toInt()
                else -> 0xFFFFFFFF.toInt()
            }
            val x = KX0 + col * KCW
            val y = KY0 + r * KCH
            rect.set(x + 0.8f, y + 0.8f, x + KCW - 0.8f, y + KCH - 0.8f)
            c.drawRoundRect(rect, 1.5f, 1.5f, fill)
        }
    }

    private fun drawMouseAndArms(c: Canvas, keyPressed: Boolean, clicking: Boolean) {
        val mcx = 250f + mX
        val mcy = 202f + mY

        // chuột
        rect.set(mcx - 9f, mcy - 6f, mcx + 9f, mcy + 16f)
        fill.color = if (clicking) 0xFFFFB8C8.toInt() else 0xFFFFFFFF.toInt()
        c.drawRoundRect(rect, 8f, 8f, fill)
        line.strokeWidth = 2.5f
        c.drawRoundRect(rect, 8f, 8f, line)
        line.strokeWidth = 1.5f
        c.drawLine(mcx - 9f, mcy + 3f, mcx + 9f, mcy + 3f, line)

        val mhx = mcx
        val mhy = mcy - 3f + if (clicking) 2f else 0f
        val khx = kx
        val khy = ky + if (keyPressed) 3f else 0f

        // tay (cánh tay)
        arm(c, 128f, 166f, khx, khy)
        arm(c, 172f, 166f, mhx, mhy)

        // bàn tay
        hand(c, khx, khy)
        hand(c, mhx, mhy)
    }

    private fun arm(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        line.strokeWidth = 15f; line.color = INK
        c.drawLine(x1, y1, x2, y2, line)
        line.strokeWidth = 9f; line.color = CREAM
        c.drawLine(x1, y1, x2, y2, line)
        line.color = INK
    }

    private fun hand(c: Canvas, x: Float, y: Float) {
        fill.color = CREAM
        c.drawCircle(x, y, 9.5f, fill)
        line.strokeWidth = 3f
        c.drawCircle(x, y, 9.5f, line)
    }
}
