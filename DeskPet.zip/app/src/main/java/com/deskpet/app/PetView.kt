package com.deskpet.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

private class KPos(val row: Int, val col: Float)
private class Ev(val isClick: Boolean, val name: String, val down: Boolean)

/**
 * Mèo ngồi bàn. Tay (phía bên trái màn hình) đặt trên bàn di chuột, tay kia gõ bàn phím.
 * Bàn phím được xoay 180° (đúng chiều nhìn của mèo): hàng Space nằm sát mèo, hàng số xa mèo nhất.
 * Các hàm push* an toàn khi gọi từ luồng khác (không làm nghẽn luồng UI khi chuột 1000Hz).
 */
class PetView(ctx: Context, var scaleFactor: Float) : View(ctx) {

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val dens = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = INK
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 6f
        color = 0xFF6F8797.toInt()
    }
    private val rect = RectF()
    private val path = Path()

    // dữ liệu từ luồng đọc input
    private val accDx = AtomicInteger(0)
    private val accDy = AtomicInteger(0)
    private val accWheel = AtomicInteger(0)
    private val queue = ConcurrentLinkedQueue<Ev>()

    // tay chuột (lệch so với vị trí nghỉ)
    private var mTx = 0f
    private var mTy = 0f
    private var mX = 0f
    private var mY = 0f

    // tay phím
    private var kx = 205f
    private var ky = 188f
    private var kTx = 205f
    private var kTy = 188f
    private var heldKey: String? = null
    private var pressRow = -1
    private var pressCol = -1f
    private var pressSpace = false
    private var keyDown = false
    private var keyPressUntil = 0L

    private var kLift = -3f
    @Volatile private var blinkUntil = 0L

    private var mouseDown = false
    private var clickUntil = 0L

    @Volatile private var activeUntil = 0L
    @Volatile private var lastPost = 0L

    companion object {
        private const val INK = 0xFF2B3A4A.toInt()
        private const val BODY = 0xFFE4F6FA.toInt()
        private const val TEAL = 0xFF7FE3D0.toInt()
        private const val KEYC = 0xFFEAF3F7.toInt()
        private const val KEYLINE = 0xFF9DB2C0.toInt()
        private const val W = 300f
        private const val H = 230f
        private const val KX0 = 126f      // mép trái vùng phím (theo chiều gõ của mèo)
        private const val KCW = 14f
        private const val KCH = 9f
        private const val SPACE_Y = 165f
        private const val SPACE_CX = 199.5f

        private val ROWS = arrayOf("1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        private val OFFS = floatArrayOf(0f, 0.5f, 0.75f, 1.25f)

        private val keyMap = HashMap<String, KPos>().apply {
            for (r in ROWS.indices) for (i in ROWS[r].indices) {
                put("KEY_${ROWS[r][i]}", KPos(r, OFFS[r] + i))
            }
            put("KEY_TAB", KPos(1, 0f)); put("KEY_CAPSLOCK", KPos(2, 0f))
            put("KEY_LEFTSHIFT", KPos(3, 0f)); put("KEY_RIGHTSHIFT", KPos(3, 8.5f))
            put("KEY_LEFTCTRL", KPos(4, 0.5f)); put("KEY_RIGHTCTRL", KPos(4, 10f))
            put("KEY_LEFTALT", KPos(4, 2f)); put("KEY_RIGHTALT", KPos(4, 9f))
            put("KEY_ENTER", KPos(2, 9.5f)); put("KEY_BACKSPACE", KPos(0, 10.5f))
            put("KEY_ESC", KPos(0, -0.5f)); put("KEY_MINUS", KPos(0, 10f)); put("KEY_EQUAL", KPos(0, 11f))
            put("KEY_COMMA", KPos(3, 7f)); put("KEY_DOT", KPos(3, 8f)); put("KEY_SLASH", KPos(3, 9f))
            put("KEY_SEMICOLON", KPos(2, 9f)); put("KEY_APOSTROPHE", KPos(2, 10f))
            put("KEY_LEFTBRACE", KPos(1, 10f)); put("KEY_RIGHTBRACE", KPos(1, 11f))
        }

        // vị trí trên màn hình: bàn phím xoay 180° quanh trục dọc giữa
        private fun keyX(col: Float) = 406f - (KX0 + col * KCW + KCW / 2)
        private fun rowY(r: Int) = if (r >= 4) SPACE_Y else 202.5f - r * KCH
    }

    // ---------- nhận tín hiệu (gọi được từ mọi luồng) ----------
    fun pushMove(dx: Int, dy: Int) { accDx.addAndGet(dx); accDy.addAndGet(dy); wake() }
    fun pushWheel(v: Int) { accWheel.addAndGet(v); wake() }
    fun pushClick(down: Boolean) { queue.offer(Ev(true, "", down)); wake() }
    fun pushKey(name: String, down: Boolean) { queue.offer(Ev(false, name, down)); wake() }

    private fun wake() {
        val now = SystemClock.uptimeMillis()
        activeUntil = now + 1500
        if (now - lastPost >= 6) {
            lastPost = now
            postInvalidateOnAnimation()
        }
    }

    // ---------- áp dụng trên luồng UI ----------
    private fun drain() {
        val dx = accDx.getAndSet(0)
        val dy = accDy.getAndSet(0)
        if (dx != 0 || dy != 0) {
            mTx = (mTx + dx * 0.7f).coerceIn(-16f, 16f)
            mTy = (mTy + dy * 0.7f).coerceIn(-10f, 10f)
        }
        val w = accWheel.getAndSet(0)
        if (w != 0) mTy = (mTy - w * 3f).coerceIn(-10f, 10f)
        while (true) {
            val e = queue.poll() ?: break
            if (e.isClick) applyClick(e.down) else applyKey(e.name, e.down)
        }
    }

    private fun applyClick(down: Boolean) {
        mouseDown = down
        if (down) clickUntil = SystemClock.uptimeMillis() + 110
    }

    private fun applyKey(name: String, down: Boolean) {
        if (down) {
            heldKey = name
            keyDown = true
            keyPressUntil = SystemClock.uptimeMillis() + 110
            if (name == "KEY_SPACE") {
                pressSpace = true
                pressRow = -1
                kTx = SPACE_CX
                kTy = SPACE_Y - 4f
            } else {
                pressSpace = false
                val pos = keyMap[name] ?: run {
                    val h = name.hashCode() and 0x7fffffff
                    val r = h % 4
                    KPos(r, OFFS[r] + (h / 4) % 10)
                }
                pressRow = pos.row
                pressCol = pos.col
                kTx = keyX(pos.col)
                kTy = rowY(pos.row) - 4f
            }
        } else if (name == heldKey) {
            keyDown = false
        }
    }

    // ---------- chớp mắt như Bongo Cat ----------
    private val blink = object : Runnable {
        override fun run() {
            blinkUntil = SystemClock.uptimeMillis() + 130
            invalidate()
            postDelayed({ invalidate() }, 150)
            postDelayed(this, 2500L + (Math.random() * 3000).toLong())
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postDelayed(blink, 2500)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(blink)
        super.onDetachedFromWindow()
    }

    // ---------- kích thước + kéo thả ----------
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (W * 0.8f * dens * scaleFactor).toInt()
        val h = (H * 0.8f * dens * scaleFactor).toInt()
        setMeasuredDimension(w, h)
    }

    private var lastX = 0f
    private var lastY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    lastX = e.rawX; lastY = e.rawY
                    onDrag?.invoke(dx, dy)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { onDragEnd?.invoke(); return true }
        }
        return super.onTouchEvent(e)
    }

    // ---------- vẽ ----------
    override fun onDraw(canvas: Canvas) {
        drain()
        val now = SystemClock.uptimeMillis()
        mTx *= 0.95f; mTy *= 0.95f
        mX += (mTx - mX) * 0.4f; mY += (mTy - mY) * 0.4f
        kx += (kTx - kx) * 0.4f; ky += (kTy - ky) * 0.4f
        val keyPressed = keyDown || now < keyPressUntil
        val clicking = mouseDown || now < clickUntil
        kLift += ((if (keyPressed) 3f else -3f) - kLift) * 0.5f

        canvas.save()
        val s = width / W
        canvas.scale(s, s)

        drawCat(canvas, keyPressed || clicking, now)
        drawDesk(canvas, clicking)
        drawKeyboard(canvas, keyPressed)
        drawArmsAndPaws(canvas, keyPressed, clicking)
        canvas.restore()

        if (now < activeUntil || !queue.isEmpty()) postInvalidateOnAnimation()
    }

    private fun drawCat(c: Canvas, active: Boolean, now: Long) {
        fill.color = BODY
        line.strokeWidth = 3.5f
        // tai nhỏ ở hai góc vòm đầu
        path.reset()
        path.moveTo(98f, 92f); path.lineTo(103f, 42f); path.lineTo(138f, 66f); path.close()
        c.drawPath(path, fill); c.drawPath(path, line)
        path.reset()
        path.moveTo(172f, 66f); path.lineTo(207f, 42f); path.lineTo(212f, 92f); path.close()
        c.drawPath(path, fill); c.drawPath(path, line)

        // đầu + thân hình vòm
        rect.set(72f, 58f, 238f, 218f)
        c.drawOval(rect, fill)
        c.drawOval(rect, line)

        val ex = mX / 16f * 2.5f
        val ey = mY / 10f * 2f

        // mắt: nhắm tít khi đang gõ/bấm hoặc đang chớp
        if (active || now < blinkUntil) {
            line.strokeWidth = 2.6f
            path.reset()
            path.moveTo(123f + ex, 98f + ey); path.quadTo(130f + ex, 90f + ey, 137f + ex, 98f + ey)
            c.drawPath(path, line)
            path.reset()
            path.moveTo(173f + ex, 98f + ey); path.quadTo(180f + ex, 90f + ey, 187f + ex, 98f + ey)
            c.drawPath(path, line)
        } else {
            fill.color = INK
            c.drawCircle(130f + ex, 95f + ey, 4.5f, fill)
            c.drawCircle(180f + ex, 95f + ey, 4.5f, fill)
        }

        // miệng: há ra khi gõ phím / bấm chuột, bình thường là ω
        if (active) {
            fill.color = INK
            rect.set(148f, 101f, 162f, 117f)
            c.drawOval(rect, fill)
            fill.color = 0xFFFF8FA3.toInt()
            rect.set(151f, 109f, 159f, 116f)
            c.drawOval(rect, fill)
        } else {
            line.strokeWidth = 2.4f
            path.reset()
            path.moveTo(144f, 103f)
            path.quadTo(149.5f, 112f, 155f, 103f)
            path.quadTo(160.5f, 112f, 166f, 103f)
            c.drawPath(path, line)
        }
    }

    private fun drawDesk(c: Canvas, clicking: Boolean) {
        rect.set(10f, 152f, 290f, 226f)
        fill.color = 0xFFD3E8F0.toInt()
        c.drawRoundRect(rect, 6f, 6f, fill)
        line.strokeWidth = 3f
        c.drawRoundRect(rect, 6f, 6f, line)

        rect.set(20f, 166f, 108f, 214f)
        fill.color = if (clicking) 0xFFA8C0D2.toInt() else 0xFFBFD0DC.toInt()
        c.drawRoundRect(rect, 8f, 8f, fill)
        line.strokeWidth = 2f
        line.color = 0xFF7C93A6.toInt()
        c.drawRoundRect(rect, 8f, 8f, line)
        line.color = INK
    }

    private fun drawKeyboard(c: Canvas, pressed: Boolean) {
        rect.set(118f, 156f, 288f, 212f)
        fill.color = 0xFFFFFFFF.toInt()
        c.drawRoundRect(rect, 5f, 5f, fill)
        line.strokeWidth = 2.5f
        c.drawRoundRect(rect, 5f, 5f, line)

        for (r in 0..3) {
            val row = ROWS[r]
            for (i in row.indices) {
                val col = OFFS[r] + i
                val cx = keyX(col)
                val cy = rowY(r)
                val hit = pressed && !pressSpace && pressRow == r && abs(pressCol - col) < 0.01f
                fill.color = if (hit) TEAL else KEYC
                rect.set(cx - KCW / 2 + 0.8f, cy - KCH / 2 + 0.5f, cx + KCW / 2 - 0.8f, cy + KCH / 2 - 0.5f)
                c.drawRoundRect(rect, 1.5f, 1.5f, fill)
                line.strokeWidth = 0.8f
                line.color = KEYLINE
                c.drawRoundRect(rect, 1.5f, 1.5f, line)
                line.color = INK
                // chữ trên phím bị ngược vì mèo nhìn từ phía bên kia
                c.save()
                c.rotate(180f, cx, cy)
                c.drawText(row[i].toString(), cx, cy + 2.2f, txt)
                c.restore()
            }
        }
        // thanh Space (hàng sát mèo)
        fill.color = if (pressed && pressSpace) TEAL else KEYC
        rect.set(161f, SPACE_Y - 5f, 238f, SPACE_Y + 5f)
        c.drawRoundRect(rect, 2.5f, 2.5f, fill)
        line.strokeWidth = 0.8f
        line.color = KEYLINE
        c.drawRoundRect(rect, 2.5f, 2.5f, line)
        line.color = INK
    }

    private fun drawArmsAndPaws(c: Canvas, keyPressed: Boolean, clicking: Boolean) {
        val mhx = 62f + mX
        val mhy = 190f + mY + if (clicking) 3f else -2f
        val khx = kx
        val khy = ky + kLift

        arm(c, 112f, 128f, mhx, mhy)
        arm(c, 200f, 128f, khx, khy)
        paw(c, mhx, mhy)
        paw(c, khx, khy)
    }

    private fun arm(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        line.strokeWidth = 26f; line.color = INK
        c.drawLine(x1, y1, x2, y2, line)
        line.strokeWidth = 20f; line.color = BODY
        c.drawLine(x1, y1, x2, y2, line)
        line.color = INK
    }

    private fun paw(c: Canvas, x: Float, y: Float) {
        fill.color = BODY
        c.drawCircle(x, y, 11f, fill)
        line.strokeWidth = 2.8f
        c.drawCircle(x, y, 11f, line)
        line.strokeWidth = 1.8f
        c.drawLine(x - 3f, y + 2f, x - 3f, y + 9f, line)
        c.drawLine(x + 3f, y + 2f, x + 3f, y + 9f, line)
    }
}
