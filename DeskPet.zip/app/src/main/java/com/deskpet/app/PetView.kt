package com.deskpet.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

/**
 * Mèo ngồi bàn: tay trái đặt trên bàn di chuột (theo chuột), tay phải gõ bàn phím.
 * Bấm phím Space -> tay mèo đập xuống thanh Space. Toàn bộ vẽ bằng Canvas.
 */
class PetView(ctx: Context, var scaleFactor: Float) : View(ctx) {

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val dens = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = INK
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rect = RectF()
    private val path = Path()

    // tay chuột (lệch so với vị trí nghỉ)
    private var mTx = 0f
    private var mTy = 0f
    private var mX = 0f
    private var mY = 0f

    // tay phím
    private var kx = 205f
    private var ky = 188f
    private var kTx = 205f
    private var kTy = 188f
    private var heldKey: String? = null
    private var keyCol = 0
    private var keyRow = 0
    private var keySpace = false
    private var keyDown = false
    private var keyPressUntil = 0L

    private var mouseDown = false
    private var clickUntil = 0L
    private var activeUntil = 0L

    companion object {
        private const val INK = 0xFF2B3A4A.toInt()
        private const val BODY = 0xFFE4F6FA.toInt()
        private const val W = 300f
        private const val H = 230f
        private const val KX0 = 126f
        private const val KY0 = 164f
        private const val KCW = 14f
        private const val KCH = 9f
        private const val COLS = 11
        private const val SPACE_L = 150f
        private const val SPACE_R = 250f
        private const val SPACE_T = 193f
        private const val SPACE_B = 205f
    }

    // ---------- nhận tín hiệu ----------
    fun onMouseMove(dx: Int, dy: Int) {
        mTx = (mTx + dx * 0.7f).coerceIn(-16f, 16f)
        mTy = (mTy + dy * 0.7f).coerceIn(-10f, 10f)
        wake()
    }

    fun onWheel(v: Int) {
        mTy = (mTy - v * 3f).coerceIn(-10f, 10f)
        wake()
    }

    fun onClick(down: Boolean) {
        mouseDown = down
        if (down) clickUntil = SystemClock.uptimeMillis() + 110
        wake()
    }

    /** name dạng "KEY_SPACE", "KEY_A"... */
    fun onKey(name: String, down: Boolean) {
        if (down) {
            heldKey = name
            keyDown = true
            keyPressUntil = SystemClock.uptimeMillis() + 110
            if (name == "KEY_SPACE") {
                keySpace = true
                kTx = (SPACE_L + SPACE_R) / 2
                kTy = SPACE_B + 4f
            } else {
                keySpace = false
                val h = name.hashCode() and 0x7fffffff
                keyCol = h % COLS
                keyRow = (h / COLS) % 3
                kTx = KX0 + keyCol * KCW + KCW / 2
                kTy = KY0 + keyRow * KCH + 12f
            }
        } else if (name == heldKey) {
            keyDown = false
        }
        wake()
    }

    private fun wake() {
        activeUntil = SystemClock.uptimeMillis() + 1500
        postInvalidateOnAnimation()
    }

    // ---------- kích thước + kéo thả ----------
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (W * 0.8f * dens * scaleFactor).toInt()
        val h = (H * 0.8f * dens * scaleFactor).toInt()
        setMeasuredDimension(w, h)
    }

    private var lastX = 0f
    private var lastY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    lastX = e.rawX; lastY = e.rawY
                    onDrag?.invoke(dx, dy)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { onDragEnd?.invoke(); return true }
        }
        return super.onTouchEvent(e)
    }

    // ---------- vẽ ----------
    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        mTx *= 0.95f; mTy *= 0.95f
        mX += (mTx - mX) * 0.4f; mY += (mTy - mY) * 0.4f
        kx += (kTx - kx) * 0.4f; ky += (kTy - ky) * 0.4f
        val keyPressed = keyDown || now < keyPressUntil
        val clicking = mouseDown || now < clickUntil

        canvas.save()
        val s = width / W
        canvas.scale(s, s)

        drawCat(canvas)
        drawDesk(canvas, clicking)
        drawKeyboard(canvas, keyPressed)
        drawArmsAndPaws(canvas, keyPressed, clicking)
        canvas.restore()

        if (now < activeUntil) postInvalidateOnAnimation()
    }

    private fun drawCat(c: Canvas) {
        // tai
        fill.color = BODY
        line.strokeWidth = 3.5f
        path.reset()
        path.moveTo(104f, 84f); path.lineTo(108f, 30f); path.lineTo(146f, 58f); path.close()
        c.drawPath(path, fill); c.drawPath(path, line)
        path.reset()
        path.moveTo(164f, 58f); path.lineTo(204f, 30f); path.lineTo(208f, 84f); path.close()
        c.drawPath(path, fill); c.drawPath(path, line)

        // thân/đầu hình vòm
        rect.set(82f, 50f, 228f, 216f)
        c.drawOval(rect, fill)
        c.drawOval(rect, line)

        // mắt nhìn theo chuột
        val ex = mX / 16f * 2.5f
        val ey = mY / 10f * 2f
        fill.color = INK
        c.drawCircle(130f + ex, 94f + ey, 4.5f, fill)
        c.drawCircle(180f + ex, 94f + ey, 4.5f, fill)

        // miệng ω
        line.strokeWidth = 2.4f
        path.reset()
        path.moveTo(144f, 100f)
        path.quadTo(149.5f, 109f, 155f, 100f)
        path.quadTo(160.5f, 109f, 166f, 100f)
        c.drawPath(path, line)
    }

    private fun drawDesk(c: Canvas, clicking: Boolean) {
        // mặt bàn che phần dưới của mèo
        rect.set(10f, 152f, 290f, 226f)
        fill.color = 0xFFD3E8F0.toInt()
        c.drawRoundRect(rect, 6f, 6f, fill)
        line.strokeWidth = 3f
        c.drawRoundRect(rect, 6f, 6f, line)

        // bàn di chuột
        rect.set(20f, 166f, 108f, 214f)
        fill.color = if (clicking) 0xFFA8C0D2.toInt() else 0xFFBFD0DC.toInt()
        c.drawRoundRect(rect, 8f, 8f, fill)
        line.strokeWidth = 2f
        line.color = 0xFF7C93A6.toInt()
        c.drawRoundRect(rect, 8f, 8f, line)
        line.color = INK
    }

    private fun drawKeyboard(c: Canvas, pressed: Boolean) {
        rect.set(118f, 158f, 286f, 214f)
        fill.color = 0xFFFFFFFF.toInt()
        c.drawRoundRect(rect, 5f, 5f, fill)
        line.strokeWidth = 2.5f
        c.drawRoundRect(rect, 5f, 5f, line)

        for (r in 0..2) for (col in 0 until COLS) {
            val hit = pressed && !keySpace && r == keyRow && col == keyCol
            fill.color = if (hit) 0xFF7FE3D0.toInt() else 0xFFEAF3F7.toInt()
            val x = KX0 + col * KCW
            val y = KY0 + r * KCH
            rect.set(x + 0.8f, y + 0.8f, x + KCW - 0.8f, y + KCH - 0.8f)
            c.drawRoundRect(rect, 1.5f, 1.5f, fill)
            line.strokeWidth = 0.8f
            line.color = 0xFF9DB2C0.toInt()
            c.drawRoundRect(rect, 1.5f, 1.5f, line)
            line.color = INK
        }
        // thanh space
        fill.color = if (pressed && keySpace) 0xFF7FE3D0.toInt() else 0xFFEAF3F7.toInt()
        rect.set(SPACE_L, SPACE_T, SPACE_R, SPACE_B)
        c.drawRoundRect(rect, 2.5f, 2.5f, fill)
        line.strokeWidth = 0.8f
        line.color = 0xFF9DB2C0.toInt()
        c.drawRoundRect(rect, 2.5f, 2.5f, line)
        line.color = INK
    }

    private fun drawArmsAndPaws(c: Canvas, keyPressed: Boolean, clicking: Boolean) {
        val mhx = 62f + mX
        val mhy = 190f + mY + if (clicking) 2f else 0f
        val khx = kx
        val khy = ky + if (keyPressed) 3f else 0f

        arm(c, 112f, 128f, mhx, mhy)
        arm(c, 200f, 128f, khx, khy)
        paw(c, mhx, mhy)
        paw(c, khx, khy)
    }

    private fun arm(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        line.strokeWidth = 26f; line.color = INK
        c.drawLine(x1, y1, x2, y2, line)
        line.strokeWidth = 20f; line.color = BODY
        c.drawLine(x1, y1, x2, y2, line)
        line.color = INK
    }

    private fun paw(c: Canvas, x: Float, y: Float) {
        fill.color = BODY
        c.drawCircle(x, y, 11f, fill)
        line.strokeWidth = 2.8f
        c.drawCircle(x, y, 11f, line)
        // hai đường ngón chân
        line.strokeWidth = 1.8f
        c.drawLine(x - 3f, y + 2f, x - 3f, y + 9f, line)
        c.drawLine(x + 3f, y + 2f, x + 3f, y + 9f, line)
    }
}
