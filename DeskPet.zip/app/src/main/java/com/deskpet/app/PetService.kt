package com.deskpet.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.ServiceCompat

class PetService : Service() {

    companion object {
        const val ACTION_STOP = "com.deskpet.app.STOP"
        const val ACTION_RESIZE = "com.deskpet.app.RESIZE"
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var pet: PetView? = null
    private var reader: InputReader? = null

    private val prefs by lazy { getSharedPreferences("pet", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    /** lock = true: chạm xuyên qua mèo (dùng khi chơi game, không kéo được). */
    private fun flagsFor(lock: Boolean): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (lock) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    override fun onCreate() {
        super.onCreate()
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = PetView(this, prefs.getInt("size", 100) / 100f)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flagsFor(prefs.getBoolean("lock", false)),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 100)
            y = prefs.getInt("y", 300)
        }
        view.onDrag = { dx, dy ->
            lp.x += dx
            lp.y += dy
            try { wm.updateViewLayout(view, lp) } catch (_: Throwable) {}
        }
        view.onDragEnd = { prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply() }
        wm.addView(view, lp)
        pet = view
        PetBus.pet = view

        reader = InputReader(view).also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_RESIZE -> pet?.let {
                it.scaleFactor = prefs.getInt("size", 100) / 100f
                lp.flags = flagsFor(prefs.getBoolean("lock", false))
                it.requestLayout()
                try { wm.updateViewLayout(it, lp) } catch (_: Throwable) {}
            }
        }
        return if (pet == null) START_NOT_STICKY else START_STICKY
    }

    override fun onDestroy() {
        reader?.shutdown()
        PetBus.pet = null
        PetBus.shizukuActive = false
        pet?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        pet = null
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("pet", "Mèo trên màn hình", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "pet")
            .setSmallIcon(R.drawable.ic_pet)
            .setContentTitle("Mèo đang chạy")
            .setContentText("Chạm để mở cài đặt")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_pet), "Tắt", stop
                ).build()
            )
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }
}
