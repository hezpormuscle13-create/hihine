package com.deskpet.app

object PetBus {
    @Volatile var shizukuActive = false
    @Volatile var pet: PetView? = null
}
