package com.deskpet.app

import java.util.concurrent.atomic.AtomicLong

object PetBus {
    @Volatile var shizukuActive = false
    @Volatile var pet: PetView? = null

    // thông tin chẩn đoán hiện trong màn hình chính
    @Volatile var status = "chưa chạy"
    @Volatile var lastEventAt = 0L
    val eventCount = AtomicLong(0)
}
