package com.deskpet.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Chạy `getevent -l` qua Shizuku (quyền shell) để đọc chuột/bàn phím thật,
 * kể cả khi đang dùng app khác.
 */
class InputReader(private val pet: PetView) : Thread("pet-input") {

    @Volatile private var running = true
    private var proc: Process? = null

    private val mouseButtons = setOf("BTN_LEFT", "BTN_RIGHT", "BTN_MIDDLE")

    private fun startProc(): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("getevent", "-l"), null, null) as Process
    }

    private fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    override fun run() {
        while (running) {
            try {
                if (ready()) {
                    val p = startProc()
                    proc = p
                    PetBus.shizukuActive = true
                    readLoop(BufferedReader(InputStreamReader(p.inputStream)))
                    p.destroy()
                }
            } catch (_: Throwable) {
            }
            PetBus.shizukuActive = false
            if (!running) break
            try { sleep(3000) } catch (_: InterruptedException) {}
        }
    }

    private fun readLoop(br: BufferedReader) {
        var dx = 0
        var dy = 0
        var wheel = 0
        while (running) {
            val line = br.readLine() ?: break
            val t = line.trim().split(Regex("\\s+"))
            if (t.size < 3) continue
            val type = t[1]
            val code = t[2]
            val v = if (t.size > 3) t[3] else ""
            try {
                when (type) {
                    "EV_REL" -> {
                        val n = v.toLong(16).toInt()
                        when (code) {
                            "REL_X" -> dx += n
                            "REL_Y" -> dy += n
                            "REL_WHEEL" -> wheel += n
                        }
                    }
                    "EV_KEY" -> {
                        val down = when (v) { "DOWN" -> true; "UP" -> false; else -> null }
                        if (down != null) {
                            if (code in mouseButtons) {
                                pet.post { pet.onClick(down) }
                            } else if (code.startsWith("KEY_")) {
                                pet.post { pet.onKey(code, down) }
                            }
                        }
                    }
                    "EV_SYN" -> {
                        if (dx != 0 || dy != 0) {
                            val ax = dx; val ay = dy
                            pet.post { pet.onMouseMove(ax, ay) }
                        }
                        if (wheel != 0) {
                            val w = wheel
                            pet.post { pet.onWheel(w) }
                        }
                        dx = 0; dy = 0; wheel = 0
                    }
                }
            } catch (_: NumberFormatException) {
            }
        }
    }

    fun shutdown() {
        running = false
        try { proc?.destroy() } catch (_: Throwable) {}
        interrupt()
    }
}
