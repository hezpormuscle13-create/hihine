package com.deskpet.app

import android.content.pm.PackageManager
import android.os.SystemClock
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.StringTokenizer
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap

/**
 * Đọc chuột/bàn phím thật qua Shizuku (quyền shell) bằng `getevent`.
 *
 * Khác bản trước:
 *  - Chỉ đọc đúng thiết bị chuột + bàn phím (bỏ màn hình cảm ứng). Khi chơi game, cảm ứng sinh ra rất nhiều
 *    dòng sự kiện, làm đầy ống đọc và khiến sự kiện chuột bị trễ/rớt -> mèo đứng im.
 *  - Mỗi thiết bị một tiến trình getevent riêng, ưu tiên luồng cao, phân tích nhẹ (không Regex mỗi dòng).
 *  - Cứ 3 giây quét lại danh sách thiết bị: cắm/rút/đổi cổng chuột hoặc tiến trình bị chết thì tự đọc lại.
 */
class InputReader(private val pet: PetView) : Thread("pet-manager") {

    @Volatile private var running = true

    private class Dev(val path: String) {
        @Volatile var proc: Process? = null
        @Volatile var alive = true
    }

    private val devs = ConcurrentHashMap<String, Dev>()
    private val mouseButtons = setOf("BTN_LEFT", "BTN_RIGHT", "BTN_MIDDLE")

    private val reRelX = Regex("\\bREL_X\\b")
    private val reRelY = Regex("\\bREL_Y\\b")
    private val reKeyA = Regex("\\bKEY_A\\b")
    private val reKeySpace = Regex("\\bKEY_SPACE\\b")
    private val reName = Regex("name:\\s+\"(.*)\"")
    private val reSplit = Regex("(?m)^add device \\d+: ")

    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    private fun newProc(cmd: Array<String>): Process =
        newProcessMethod.invoke(null, cmd, null, null) as Process

    private fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    /** Trả về map đường dẫn -> tên của chuột/bàn phím; null nếu không đọc được danh sách. */
    private fun scan(): Map<String, String>? = try {
        val p = newProc(arrayOf("getevent", "-lp"))
        val text = p.inputStream.bufferedReader().use { it.readText() }
        try { p.waitFor() } catch (_: Throwable) {}
        parseDevices(text)
    } catch (_: Throwable) { null }

    private fun parseDevices(text: String): Map<String, String>? {
        val parts = text.split(reSplit)
        if (parts.size <= 1) return null
        val out = TreeMap<String, String>()
        for (b in parts.drop(1)) {
            val path = b.lineSequence().firstOrNull()?.trim() ?: continue
            if (!path.startsWith("/dev/input/")) continue
            val isMouse = reRelX.containsMatchIn(b) && reRelY.containsMatchIn(b)
            val isKbd = reKeyA.containsMatchIn(b) && reKeySpace.containsMatchIn(b)
            if (isMouse || isKbd) {
                out[path] = reName.find(b)?.groupValues?.get(1) ?: path.substringAfterLast('/')
            }
        }
        return out
    }

    override fun run() {
        while (running) {
            try {
                if (ready()) {
                    manage()
                } else {
                    stopAll()
                    PetBus.status = "Shizuku chưa chạy hoặc chưa cấp quyền"
                }
            } catch (_: Throwable) {
            }
            try { sleep(3000) } catch (_: InterruptedException) {}
        }
        stopAll()
    }

    private fun manage() {
        devs.entries.removeIf { !it.value.alive }
        val found = scan()
        if (found == null) {
            // không đọc được danh sách thiết bị -> đọc tất cả như cách cũ
            if (!devs.containsKey("*")) startDev("*")
            PetBus.status = "đọc tất cả thiết bị (chế độ dự phòng)"
        } else {
            devs["*"]?.let { stopDev(it) }
            for (path in found.keys) if (!devs.containsKey(path)) startDev(path)
            for (d in devs.values.toList()) if (d.path !in found) stopDev(d)
            PetBus.status = if (found.isEmpty()) "chưa thấy chuột/bàn phím OTG"
            else found.values.joinToString(", ")
        }
        PetBus.shizukuActive = devs.values.any { it.alive }
    }

    private fun startDev(path: String) {
        val d = Dev(path)
        devs[path] = d
        val t = Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY)
            try {
                val cmd = if (path == "*") arrayOf("getevent", "-l") else arrayOf("getevent", "-l", path)
                val p = newProc(cmd)
                d.proc = p
                PetBus.shizukuActive = true
                readLoop(BufferedReader(InputStreamReader(p.inputStream), 16384), d)
                try { p.destroy() } catch (_: Throwable) {}
            } catch (_: Throwable) {
            } finally {
                d.alive = false
                PetBus.shizukuActive = devs.values.any { it.alive }
            }
        }
        t.name = "pet-dev"
        t.isDaemon = true
        t.start()
    }

    private fun stopDev(d: Dev) {
        d.alive = false
        try { d.proc?.destroy() } catch (_: Throwable) {}
        devs.remove(d.path)
    }

    private fun stopAll() {
        for (d in devs.values.toList()) stopDev(d)
        PetBus.shizukuActive = false
    }

    private fun readLoop(br: BufferedReader, d: Dev) {
        var dx = 0
        var dy = 0
        var wheel = 0
        while (running && d.alive) {
            val line = br.readLine() ?: break
            // dòng có thể là "/dev/input/event5: EV_REL REL_X 00000001" hoặc "EV_REL REL_X 00000001"
            val i = line.indexOf("EV_")
            if (i < 0) continue
            val st = StringTokenizer(line.substring(i))
            if (st.countTokens() < 2) continue
            val type = st.nextToken()
            val code = st.nextToken()
            val v = if (st.hasMoreTokens()) st.nextToken() else ""
            try {
                when (type) {
                    "EV_REL" -> {
                        val n = v.toLong(16).toInt()
                        when (code) {
                            "REL_X" -> dx += n
                            "REL_Y" -> dy += n
                            "REL_WHEEL" -> wheel += n
                        }
                    }
                    "EV_KEY" -> {
                        val down = when (v) { "DOWN" -> true; "UP" -> false; else -> null }
                        if (down != null) {
                            if (code in mouseButtons) {
                                pet.pushClick(down)
                                mark()
                            } else if (code.startsWith("KEY_")) {
                                pet.pushKey(code, down)
                                mark()
                            }
                        }
                    }
                    "EV_SYN" -> {
                        if (code == "SYN_REPORT") {
                            if (dx != 0 || dy != 0) { pet.pushMove(dx, dy); mark() }
                            if (wheel != 0) { pet.pushWheel(wheel); mark() }
                            dx = 0; dy = 0; wheel = 0
                        }
                    }
                }
            } catch (_: NumberFormatException) {
            }
        }
    }

    private fun mark() {
        PetBus.eventCount.incrementAndGet()
        PetBus.lastEventAt = SystemClock.uptimeMillis()
    }

    fun shutdown() {
        running = false
        stopAll()
        interrupt()
    }
}
